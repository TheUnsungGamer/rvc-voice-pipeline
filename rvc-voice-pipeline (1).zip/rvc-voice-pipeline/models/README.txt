Drop your RVC model files here:

  my_voice.pth    ← required
  my_voice.index  ← optional but recommended for better similarity

Subdirectories are supported — the UI will recurse into them.
